package br.tips.core.services.cache;

import java.util.List;
import java.util.Map;



public class CoreCache {
	
/*	//public static ServiceCache cache;
	
	private static HazelcastInstance instance;
	
	static{
		//cache = new ServiceCache();
		ClientNetworkConfig netConfig = new ClientNetworkConfig();
		netConfig.addAddress("127.0.0.1:5701");
		ClientConfig config = new ClientConfig();
		config.setNetworkConfig(netConfig);
		instance = HazelcastClient.newHazelcastClient(config);

	}

	public CoreCache() {
		super();
		
	}
	
	public static void setResponse(String request, String response){
		if (1==1) return;
		Map<String, String> cache = instance.getMap("cache");
		cache.put(request, response);
		
	}
	
	public static String getResponse(String request){
		if (1==1) return null;
		Map<String, String> cache = instance.getMap("cache");
		return cache.get(request);
	}
	
	public static List<String> getResponseList(String request){
		if (1==1) return null;
		Map<String, List<String>> cache = instance.getMap("cacheList");
		return cache.get(request);
	}
	
	public static void setResponseList(String request, List<String> response){
		if (1==1) return;
		Map<String, List<String>> cache = instance.getMap("cacheList");
		cache.put(request, response);
		Thread t= new Thread(new CacheForecaster(request, response),"Forecaster");
		t.start();
	}
	
	public static void printCache(){
		Map<String, List<String>> cacheL = instance.getMap("cacheList");
		for (String key : cacheL.keySet()) {
			System.out.println(key+"->"+cacheL.get(key));
		}
		Map<String, String> cache = instance.getMap("cache");
		for (String key : cache.keySet()) {
			System.out.println(key+"->"+cache.get(key));
		}
	}

	public static void close(){
		instance.shutdown();
	}*/
	
}
