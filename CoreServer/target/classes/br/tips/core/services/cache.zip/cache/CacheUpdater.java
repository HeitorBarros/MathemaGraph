package br.tips.core.services.cache;

import java.util.TimerTask;

public class CacheUpdater extends TimerTask {

	public void run(){
		
	}
	
	
	
	
}
