package br.tips.core.services.cache;

import br.tips.core.model.entities.CourseModel;
import br.tips.core.properties.PropertyNames;

public class Cache4CourseModels {
	
	public static void putInCache(CourseModel cm){
		String id = cm.getId();
		System.out.println("CACHE - Putting Course model "+id+" in cache.");
		CoreCache.setResponse(buildKey(PropertyNames.GETLABEL, id), cm.getLabel());
		CoreCache.setResponse(buildKey(PropertyNames.GETROOT, id), cm.getRootTopic().getId());
		CoreCache.setResponseList(buildKey(PropertyNames.GETTOPICS, id), cm.getTopicsAndLabels());
		
		
	}
	
	private static String buildKey(String property, String id){
		return "CourseModel:"+property+":"+id;
	}

}
