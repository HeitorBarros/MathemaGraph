package br.tips.core.services.cache;

import java.util.ArrayList;
import java.util.List;

import br.tips.core.model.entities.Topic;
import br.tips.core.properties.PropertyNames;

public class Cache4Topics {
	
	
	public static void putInCache(Topic t){
		System.out.println("Putting Topic "+ t+ "in cache.");
		String id = t.getId();
		
		String label = t.getLabel();
		CoreCache.setResponse(buildKey(PropertyNames.GETLABEL, id), label);
		
		CoreCache.setResponseList(buildKey(PropertyNames.GETNEXT, id), toIdList(t.getNext()));
		
		CoreCache.setResponseList(buildKey(PropertyNames.GETPREVIOUS, id), toIdList(t.getPrevious()));
		CoreCache.setResponseList(buildKey(PropertyNames.GETPARENTS, id), toIdList(t.getSupertopics()));
		CoreCache.setResponseList(buildKey(PropertyNames.GETSUBTOPICS, id), toIdList(t.getSubtopics()));
		CoreCache.setResponseList(buildKey(PropertyNames.GETEQUIVALENTMAPPING, id), toIdList(t.getEquivalentMapping()));
		CoreCache.setResponseList(buildKey(PropertyNames.GETPRECEDESMAPPING, id), toIdList(t.getPrecedesMapping()));
		CoreCache.setResponseList(buildKey(PropertyNames.GETSPECIALIZEDBYMAPPING, id), toIdList(t.getSpecializedMapping()));
		
		System.out.println(CoreCache.getResponseList(buildKey(PropertyNames.GETSUBTOPICS, id)));
		CoreCache.printCache();
	}
	
	private static String buildKey(String property, String id){
		return "Topic:"+property+":"+id;
	}
	
	private static List<String> toIdList(List<Topic> topics){
		List<String> l = new ArrayList<String>();
		for (Topic topic : topics) {
			l.add(topic.getId());
		}
		return l;
	}
	
	public static void main(String[] args) {
		CoreCache.printCache();
	}

}
