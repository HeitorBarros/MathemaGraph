package br.tips.core.services.cache;

import java.util.List;

import javax.ws.rs.core.Response;

import br.tips.core.model.entities.CourseModel;
import br.tips.core.model.entities.EntityBuilder;
import br.tips.core.model.entities.Topic;
import br.tips.core.properties.PropertyNames;
import br.tips.core.services.CourseModelService;
import br.tips.core.services.TopicService;

public class CacheForecaster implements Runnable{

	private String request;
	private List<String> responseList;
	private String response;
	private String entityType;
	private String entityId;
	private String method;
	
	
	
	public CacheForecaster(String request, List<String> response) {
		this.request = request;
		String[] tokens = request.split(":");
		entityType = tokens[0];
		method = tokens[1];
		if (tokens.length>2) {
			entityId = tokens[2];
		}
		
		
		responseList = response;
	}

	public void run(){
		
		switch(entityType){
		case "CourseModel":
			this.handleCourseModel();
			break;
		}
		
		
		
	}

	private void handleCourseModel() {
		switch (method) {
		case PropertyNames.GETALL:
			for (String modelId : responseList) {
				CourseModel cm = EntityBuilder.buildCourseModel(modelId);
				Cache4CourseModels.putInCache(cm);
				Topic root = cm.getRootTopic();
				Cache4Topics.putInCache(root);
			}
			break;
			
		case PropertyNames.GETTOPICSANDLABELS:
			
			break;

		default:
			break;
		}
		
		CoreCache.printCache();
	}
}
